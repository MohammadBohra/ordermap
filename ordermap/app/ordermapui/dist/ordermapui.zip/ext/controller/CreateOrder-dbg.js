sap.ui.define([
  "sap/m/MessageToast",
  "sap/m/MessageBox"
], function (MessageToast, MessageBox) {
  'use strict';

  return {
    /**
     * Generated event handler.
     *
     * @param oContext the context of the page on which the event was fired. `undefined` for list report page.
     * @param aSelectedContexts the selected contexts of the table rows.
     */

    create_sales_order: async function (oContext, aSelectedContexts) {
      try {
        

        if (!aSelectedContexts || aSelectedContexts.length === 0) {
          MessageToast.show("Please select a row to create SAP order.");
          return;
        }

        const oRowContext = aSelectedContexts[0]; // single select
        const oRowData = oRowContext.getObject();
        
        const SapOrderId = oRowData.SapOrderId;
        const IdocNumber = oRowData.IdocNumber;
        const MessageType = oRowData.MessageType;
        const Message = oRowData.Message;
        const isBlank = v =>
          v === null ||
          v === undefined ||
          v === "" ||
          (typeof v === "string" && /^0+$/.test(v));
        const oThat = this;
        const shouldCallOrderCreationAPI =
          isBlank(SapOrderId) &&
          (
            isBlank(IdocNumber) ||
            (!isBlank(IdocNumber) && MessageType === "E")
          );

        // Do we need confirmation?
        const needsConfirmation =
          !isBlank(IdocNumber) && MessageType === "E";

        if (needsConfirmation) {
          
          MessageBox.confirm(
            "Previous order submission failed.\n\nValidate the order details before submitting a new request. \n\n Do you want to submit a new reqtuest?",
            {
              title: "Confirm Order Creation",
              actions: [MessageBox.Action.NO, MessageBox.Action.YES],
              emphasizedAction: MessageBox.Action.NO,
              onClose: async function (oAction) {
                if (oAction === MessageBox.Action.YES) {
                  //await oThat.proceedWithOrderCreation(shouldCallOrderCreationAPI,oRowContext);


// **********************START ***************

if (shouldCallOrderCreationAPI) {

        const input = oRowContext.sPath;
        var OrderId = "";
        var WebServiceID = "";

        const match = input.match(/OrderId=(\d+),WebServiceID='([^']+)'/);

        if (match) {
          OrderId = match[1];
          WebServiceID = match[2];
        }
        
        const oContext = oRowContext.getModel().bindContext("/create_sales_order(...)");
        oContext.setParameter("OrderId", OrderId);
        oContext.setParameter("WebServiceID", WebServiceID);
        oContext.setParameter("APIName",oRowContext.getObject().APIName);
        

        // Execute action
        
  await oContext.execute().catch(function (e) {
    let sMessage = "Order creation failed.";

    if (e?.error?.message) {
      sMessage = e.error.message;
    } else if (e?.message) {
      sMessage = e.message;
    }

    MessageBox.error(sMessage);
    sap.ui.getCore().getMessageManager().removeAllMessages();
    return Promise.reject(e);
  });  

             
        const result = oContext.getBoundContext().getObject();
        const orderNumber = result.SapOrderId || '';
        const idocNumber = result.IdocNumber || '';
        const msgType = result.MessageType;
        const message = result.Message || '';

        if (!msgType) {
          MessageBox.error("Order creation failed. Unknown error occurred.");
        }
        else if (msgType === 'S') {
          MessageBox.success(
            `SAP IDoc created successfully for BigCommerce order ${result.OrderId}.\nIDoc Number: ${idocNumber || 'N/A'}`
          );
        }
        else if (msgType === 'E') {
          MessageBox.error(
            `Order ${result.OrderId} creation failed.\n${message || 'Unknown error occurred.'}`
          );
        }
        else {
          MessageBox.information(message || "Unexpected response received.");
        }
      }
      else {
        // Informational messages
        if (!isBlank(SapOrderId)) {
          MessageBox.information(
            `SAP order already exists.\nSAP order number: ${SapOrderId}`
          );
        } else if (!isBlank(IdocNumber)) {
          MessageBox.information(
            `SAP order creation is already in progress.\nIDoc number: ${IdocNumber}`
          );
        } else if (MessageType && MessageType !== "E") {
          MessageBox.information(
            `SAP order creation cannot be triggered.\nCurrent message type: ${Message}`
          );
        } else {
          MessageBox.information(
            "SAP Order creation cannot be triggered for the selected record."
          );
        }
        return;
      }
// ***********************END **************






                }
              }
            }
          );
        } else {
          // No confirmation required → proceed directly


          
      if (shouldCallOrderCreationAPI) {

        const input = oRowContext.sPath;
        var OrderId = "";
        var WebServiceID = "";

        const match = input.match(/OrderId=(\d+),WebServiceID='([^']+)'/);

        if (match) {
          OrderId = match[1];
          WebServiceID = match[2];
        }

        const oContext = oRowContext.getModel().bindContext("/create_sales_order(...)");
        oContext.setParameter("OrderId", OrderId);
        oContext.setParameter("WebServiceID", WebServiceID);

        // Execute action
        await oContext.execute();        
        const result = oContext.getBoundContext().getObject();
        const orderNumber = result.SapOrderId || '';
        const idocNumber = result.IdocNumber || '';
        const msgType = result.MessageType;
        const message = result.Message || '';

        if (!msgType) {
          MessageBox.error("Order creation failed. Unknown error occurred.");
        }
        else if (msgType === 'S') {
          MessageBox.success(
            `SAP IDoc created successfully for BigCommerce order ${result.OrderId}.\nIDoc Number: ${idocNumber || 'N/A'}`
          );
        }
        else if (msgType === 'E') {
          MessageBox.error(
            `Order ${result.OrderId} creation failed.\n${message || 'Unknown error occurred.'}`
          );
        }
        else {
          MessageBox.information(message || "Unexpected response received.");
        }
      }
      else {
        // Informational messages
        if (!isBlank(SapOrderId)) {
          sap.m.MessageBox.information(
            `SAP Order already exists.\nSAP Order Number: ${SapOrderId}`
          );
        } else if (!isBlank(IdocNumber)) {
          sap.m.MessageBox.information(
            `SAP Order creation is already in progress.\nIDoc Number: ${IdocNumber}`
          );
        } else if (MessageType && MessageType !== "E") {
          sap.m.MessageBox.information(
            `SAP Order creation cannot be triggered.\nMissing SAP information`
          );
        } else {
          sap.m.MessageBox.information(
            "SAP Order creation cannot be triggered for the selected record."
          );
        }
        return;
      }
          
        }


      } catch (e) {
        MessageBox.error(e.error.message );
       sap.ui.getCore().getMessageManager().removeAllMessages();
      }
    },


  };
});
